"""FastAPI server 包。"""
